import {Component, ViewEncapsulation} from '@angular/core';

@Component({

  selector: 'app-recruitment',
  templateUrl: './recruitment.component.html',
  styleUrls: ['./recruitment.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class RecruitmentComponent {

  constructor() {
  }
}
